<div class="header">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            <img src="images/l0go.png" alt="Logo" style="
  position: absolute;
  top: 0;
  left: 12;
  width: 180px;     /* Adjust size */
  height: auto;    /* Maintain aspect ratio */
  margin: 5px;    /* Optional padding from edges */
">
            </div>
            <div class="col-lg-8 col-md-4 col-sm-12 col-xs-12">
                <div class="navigation">
                    <div id="navigation">
                        <ul>
                            <li class="active"><a href="index.php" title="Home">Home</a></li>
                            <li class="active"><a href="about.php" title="About">About</a></li>
                            <li><a href="service-list.php" title="Service List">Services</a></li>
                            <li><a href="appointment.php" title="Styleguide">Book Appointment</a> </li>
                            <li><a href="staff.php" title="Contact Us">Staff</a> </li>
                            <li><a href="contact.php" title="Contact Us">Contact</a> </li>
                            <li><a href="login.php" title="Contact Us">logout</a> </li>
                           

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
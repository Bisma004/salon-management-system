<!--footer-->
    <div class="footer">
       <p>&copy;  BIA Salon Management System Admin Panel || Created by BISMA</p>
    </div>
        <!--//footer-->
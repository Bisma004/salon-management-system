<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bpmsaid'] == 0)) {
    header('location:logout.php');
} else {

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $speciality = $_POST['speciality'];

    $query = mysqli_query($con, "INSERT INTO tblstaff(Name, Speciality) VALUES('$name', '$speciality')");
    if ($query) {
        echo "<script>alert('Staff has been added.');</script>";
        echo "<script>window.location.href = 'add-staff.php'</script>";
    } else {
        echo "<script>alert('Something went wrong. Please try again.');</script>";
    }
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <title>SALON | Add Staff</title>
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/font-awesome.css" rel="stylesheet"> 
    <link href="css/animate.css" rel="stylesheet" type="text/css" media="all">
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/modernizr.custom.js"></script>
    <script src="js/wow.min.js"></script>
    <script> new WOW().init(); </script>
    <script src="js/metisMenu.min.js"></script>
    <script src="js/custom.js"></script>
    <link href="css/custom.css" rel="stylesheet">
</head> 
<body class="cbp-spmenu-push">
    <div class="main-content">
        <?php include_once('includes/sidebar.php'); ?>
        <?php include_once('includes/header.php'); ?>

        <div id="page-wrapper">
            <div class="main-page">
                <div class="forms">
                    <h3 class="title1">Add Staff</h3>
                    <div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
                        <div class="form-title">
                            <h4>Staff Details:</h4>
                        </div>
                        <div class="form-body">
                            <form method="post">
                                <div class="form-group"> 
                                    <label>Staff Name</label> 
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" required="true"> 
                                </div>
                                <div class="form-group"> 
                                    <label>Speciality</label> 
                                    <input type="text" class="form-control" id="speciality" name="speciality" placeholder="e.g. Hair Stylist, Makeup Artist" required="true"> 
                                </div>
                                <button type="submit" name="submit" class="btn btn-default">Add Staff</button> 
                            </form> 
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php include_once('includes/footer.php'); ?>
    </div>

    <script src="js/classie.js"></script>
    <script>
        var menuLeft = document.getElementById('cbp-spmenu-s1'),
            showLeftPush = document.getElementById('showLeftPush'),
            body = document.body;

        showLeftPush.onclick = function () {
            classie.toggle(this, 'active');
            classie.toggle(body, 'cbp-spmenu-push-toright');
            classie.toggle(menuLeft, 'cbp-spmenu-open');
            disableOther('showLeftPush');
        };

        function disableOther(button) {
            if (button !== 'showLeftPush') {
                classie.toggle(showLeftPush, 'disabled');
            }
        }
    </script>
    <script src="js/jquery.nicescroll.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.js"></script>
</body>
</html>
<?php } ?>

<?php
include("includes/dbconnection.php");

// Define dates
$today = date("Y-m-d");
$yesterday = date("Y-m-d", strtotime("-1 day"));
$tomorrow = date("Y-m-d", strtotime("+1 day"));

// Create an array of dates
$dates = [
    $yesterday => "Yesterday",
    $today => "Today",
    $tomorrow => "Tomorrow"
];

// Fetch appointments
$query = mysqli_query($con, "
    SELECT 
        a.ID, 
        c.Name AS CustomerName, 
        s.ServiceName, 
        st.Name AS StaffName, 
        a.AppointmentTime,
        a.AppointmentDate
    FROM tblappointments a
    JOIN tblcustomers c ON a.CustomerID = c.ID
    JOIN tblservices s ON a.ServiceID = s.ID
    JOIN tblstaff st ON a.StaffID = st.ID
    WHERE a.AppointmentDate IN ('$yesterday', '$today', '$tomorrow')
    ORDER BY a.AppointmentDate, a.AppointmentTime
");

$appointments = [];
while ($row = mysqli_fetch_assoc($query)) {
    $date = $row['AppointmentDate'];
    $appointments[$date][] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - 3 Days Appointments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card-header {
            background-color: #343a40;
            color: white;
        }
        .badge-today {
            background-color: #0d6efd;
        }
        .badge-yesterday {
            background-color: #6c757d;
        }
        .badge-tomorrow {
            background-color: #198754;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="text-center mb-4">
        <h2 class="fw-bold">Salon Appointments</h2>
        <p class="text-muted">Overview for Yesterday, Today & Tomorrow</p>
    </div>

    <?php
    foreach ($dates as $date => $label) {
        $badgeClass = match($label) {
            "Today" => "badge-today",
            "Yesterday" => "badge-yesterday",
            "Tomorrow" => "badge-tomorrow",
            default => "bg-secondary"
        };

        echo "
        <div class='card mb-4 shadow-sm'>
            <div class='card-header d-flex justify-content-between align-items-center'>
                <h5 class='mb-0'>{$label} <span class='badge {$badgeClass} ms-2'>{$date}</span></h5>
            </div>
            <div class='card-body'>";

        if (isset($appointments[$date])) {
            echo "<div class='table-responsive'>
                    <table class='table table-bordered table-hover'>
                        <thead class='table-light'>
                            <tr>
                                <th>#</th>
                                <th>Customer</th>
                                <th>Service</th>
                                <th>Staff</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>";
            $count = 1;
            foreach ($appointments[$date] as $appt) {
                echo "<tr>
                        <td>{$count}</td>
                        <td>{$appt['CustomerName']}</td>
                        <td>{$appt['ServiceName']}</td>
                        <td>{$appt['StaffName']}</td>
                        <td>{$appt['AppointmentTime']}</td>
                    </tr>";
                $count++;
            }
            echo "</tbody></table></div>";
        } else {
            echo "<p class='text-muted mb-0'>No appointments scheduled for {$label}.</p>";
        }

        echo "</div></div>";
    }
    ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

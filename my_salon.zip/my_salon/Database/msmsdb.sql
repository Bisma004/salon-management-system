-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2023 at 01:42 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `msmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL,
  `AdminName` char(50) DEFAULT NULL,
  `UserName` char(50) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `AdminRegdate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`, `AdminRegdate`) VALUES
(1, 'Admin', 'admin', 9365524166, 'tester1@gmail.com', '21232f297a57a5a743894a0e4a801fc3', '2019-07-25 06:21:50');

-- --------------------------------------------------------

--
-- Table structure for table `tblappointment`
--

CREATE TABLE `tblappointment` (
  `ID` int(10) NOT NULL,
  `AptNumber` varchar(80) DEFAULT NULL,
  `Name` varchar(120) DEFAULT NULL,
  `Email` varchar(120) DEFAULT NULL,
  `PhoneNumber` bigint(11) DEFAULT NULL,
  `AptDate` varchar(120) DEFAULT NULL,
  `AptTime` varchar(120) DEFAULT NULL,
  `Services` varchar(120) DEFAULT NULL,
  `ApplyDate` timestamp NULL DEFAULT current_timestamp(),
  `Remark` varchar(250) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `RemarkDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------
CREATE TABLE `tblstaff` (
  `ID` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(100) NOT NULL,
  `Speciality` VARCHAR(255) NOT NULL,
  `CreationDate` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
);
INSERT INTO `tblstaff` (`Name`, `Speciality`) VALUES
-- Male Staff
('Ahsan Khan', 'Hair Stylist'),
('Ali Raza', 'Beard Grooming Expert'),
('Bilal Sheikh', 'Massage Therapist'),
('Zubair Ahmed', 'Hair Color Specialist'),

-- Female Staff
('Sara Malik', 'Skin Care Specialist'),
('Fatima Zahra', 'Facial and Makeup Artist'),
('Zoya Khan', 'Nail Technician'),
('Mehak Javed', 'Waxing and Threading Specialist');

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomers`
--

CREATE TABLE `tblcustomers` (
  `ID` INT(10) NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(120) DEFAULT NULL,
  `Email` VARCHAR(200) DEFAULT NULL,
  `MobileNumber` BIGINT(11) DEFAULT NULL,
  `AptNumber` VARCHAR(120) DEFAULT NULL,
  `Gender` ENUM('Female','Male','Transgender') DEFAULT NULL,
  `app_date` VARCHAR(120) DEFAULT NULL,
  `app_time` VARCHAR(120) DEFAULT NULL,
  `Details` MEDIUMTEXT DEFAULT NULL,
  `StaffID` INT DEFAULT NULL,
  `CreationDate` TIMESTAMP NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  CONSTRAINT `fk_staff` FOREIGN KEY (`StaffID`) REFERENCES `tblstaff`(`ID`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblinvoice`
--

CREATE TABLE `tblinvoice` (
  `id` int(11) NOT NULL,
  `Userid` int(11) DEFAULT NULL,
  `ServiceId` int(11) DEFAULT NULL,
  `BillingId` int(11) DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblinvoice`
--

INSERT INTO `tblinvoice` (`id`, `Userid`, `ServiceId`, `BillingId`, `PostingDate`) VALUES
(43, 37, 8, 165333293, '2023-04-25 08:15:53'),
(44, 38, 2, 162292257, '2023-04-25 08:17:27');

-- --------------------------------------------------------



--
-- Table structure for table `tblpage`
--

CREATE TABLE `tblpage` (
  `ID` int(10) NOT NULL,
  `PageType` varchar(200) DEFAULT NULL,
  `PageTitle` mediumtext DEFAULT NULL,
  `PageDescription` mediumtext DEFAULT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `MobileNumber` bigint(10) DEFAULT NULL,
  `UpdationDate` date DEFAULT NULL,
  `Timing` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblpage`
--

INSERT INTO `tblpage` (`ID`, `PageType`, `PageTitle`, `PageDescription`, `Email`, `MobileNumber`, `UpdationDate`, `Timing`) VALUES
(1, 'aboutus', 'About Us', '                                                                                                        Our main focus is on quality and hygiene. Our Parlour is well equipped with advanced technology equipments and provides best quality services. Our staff is well trained and experienced, offering advanced services in Skin, Hair and Body Shaping that will provide you with a luxurious experience that leave you feeling relaxed and stress free. The specialities in the parlour are, apart from regular bleachings and Facials, many types of hairstyles, Bridal and cine make-up and different types of Facials &amp; fashion hair colourings.quality services. Our staff is well trained and experienced, offering advanced services in Skin, Hair and Body Shaping that will provide you with a luxurious experience that leave you feeling relaxed and stress free. The specialities in the parlour are, apart.colourings.quality services. Our staff is well trained and experienced, offering advanced services in Skin, Hair and Body Shaping that will provide you with a luxurious experience that leave you feeling relaxed and stress free. The specialities in the parlour are, apart.colourings.quality services. Our staff is well trained and experienced, offering advanced services in Skin, Hair and Body Shaping that will provide you.', NULL, NULL, NULL, ''),
(2, 'contactus', 'Contact Us', 'Nerim, Assam', 'Abhishek@gmail.com', 9365524166, NULL, '10:30 am to 8:30 pm');

-- --------------------------------------------------------

--
-- Table structure for table `tblservices`
--

CREATE TABLE `tblservices` (
  `ID` int(10) NOT NULL,
  `ServiceName` varchar(200) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `Cost` int(10) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblservices`
--

INSERT INTO tblservices (ServiceName, Description, Cost, CreationDate) VALUES
('Fruit Facial', 'Nourishes skin with fruit extracts, brightens and hydrates.', 3000, '2023-01-01 10:00:00'),
('Charcoal Facial', 'Deep-cleansing facial that removes impurities and oil.', 5000, '2023-01-02 11:00:00'),
('Gold Facial', 'Rejuvenating facial using 24K gold particles for glowing skin.', 10000, '2023-01-03 12:00:00'),
('Diamond Facial', 'Brightens complexion and removes tan for radiant skin.', 13000, '2023-01-04 13:00:00'),
('Deluxe Manicure', 'Luxury manicure with massage, scrub, and nail polish.', 800, '2023-01-05 14:00:00'),
('Deluxe Pedicure', 'Foot soak, scrub, massage, and polish for smooth feet.', 900, '2023-01-06 15:00:00'),
('Normal Manicure', 'Basic nail care with shaping and regular polish.', 500, '2023-01-07 16:00:00'),
('Normal Pedicure', 'Simple pedicure with foot soak and regular polish.', 600, '2023-01-08 17:00:00'),
('Hair Cut', 'Basic hair cut customized to your face shape.', 500, '2023-01-09 18:00:00'),
('Layer Cut', 'Chic layered haircut for volume and movement.', 900, '2023-01-10 19:00:00'),
('Step Cut', 'Stylish step cut ideal for long hair.', 1000, '2023-01-11 20:00:00'),
('Hair Wash', 'Hair cleansing with premium shampoo and conditioner.', 400, '2023-01-12 10:30:00'),
('Hair Spa', 'Nourishing treatment for smooth and shiny hair.', 1200, '2023-01-13 11:00:00'),
('Hair Straightening', 'Chemical treatment for straight, sleek hair.', 3500, '2023-01-14 12:00:00'),
('Hair Curling', 'Temporary curls styled with heat tools.', 1000, '2023-01-15 13:00:00'),
('Bridal Makeup', 'Complete bridal makeover with high-end products.', 6000, '2023-01-16 14:00:00'),
('Party Makeup', 'Glam look for parties and weddings.', 3000, '2023-01-17 15:00:00'),
('Casual Makeup', 'Natural look makeup for daily wear.', 1500, '2023-01-18 16:00:00'),
('Eyebrow Threading', 'Shaping eyebrows using traditional threading.', 200, '2023-01-19 17:00:00'),
('Full Face Threading', 'Complete facial hair removal using thread.', 600, '2023-01-20 18:00:00'),
('Full Body Waxing', 'Complete body waxing using premium wax.', 2500, '2023-01-21 19:00:00'),
('Upper Lip Waxing', 'Quick upper lip hair removal.', 150, '2023-01-22 20:00:00');
-- --------------------------------------------------------

--
-- Table structure for table `tblsubscriber`
--

CREATE TABLE `tblsubscriber` (
  `ID` int(5) NOT NULL,
  `Email` varchar(200) DEFAULT NULL,
  `DateofSub` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblsubscriber`
--

INSERT INTO `tblsubscriber` (`ID`, `Email`, `DateofSub`) VALUES
(47, 'bismabaloch53@gmail.com', '2025-07-19 14:43:57'),
(48, 'bismabaloch53@gmail.com', '2025-07-19 14:47:43'),
(50, 'bismabaloch53@gmail.com', '2025-07-19 14:51:36'),
(51, 'bismabaloch53@gmail.com', '2025-07-19 14:52:57'),
(52, 'bismabaloch53@gmail.com', '2025-07-19 14:55:31');
--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblappointment`
--
ALTER TABLE `tblappointment`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblcustomers`
--
ALTER TABLE `tblcustomers`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `AptTime` (`ID`);

--
-- Indexes for table `tblinvoice`
--
ALTER TABLE `tblinvoice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `tblpage`
--
ALTER TABLE `tblpage`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblservices`
--
ALTER TABLE `tblservices`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblsubscriber`
--
ALTER TABLE `tblsubscriber`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblappointment`
--
ALTER TABLE `tblappointment`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblcustomers`
--
ALTER TABLE `tblcustomers`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tblinvoice`
--
ALTER TABLE `tblinvoice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tblpage`
--
ALTER TABLE `tblpage`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblservices`
--
ALTER TABLE `tblservices`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tblsubscriber`
--
ALTER TABLE `tblsubscriber`
  MODIFY `ID` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
